# Zenodo Archive Guide

## Archive contents

This archive contains the complete analysis software, results, and manuscript for:

**"Spaceflight alters plant circadian clock phase: A ChronoGauge analysis of NASA GeneLab Arabidopsis transcriptomics"**

## Structure

```
spaceflight-circadian-decoder/
├── src/                          # Analysis source code
│   ├── data_acquisition.py       # GeneLab OSDR API download
│   ├── metadata_curation.py      # ISA-Tab metadata parsing
│   ├── chronogauge_apply.py      # ChronoGauge ensemble inference
│   ├── statistical_analysis.py   # Watson-Williams + metafor meta-analysis
│   ├── run_analysis.py           # Main pipeline orchestrator
│   ├── generate_validation.py    # Validation figures/tables
│   ├── figures/generate_figures.py
│   └── tables/generate_tables.py
├── config/study_lists.json       # Fork A/B study definitions
├── tests/test_pipeline.py        # Unit tests
├── results/                      # All analysis outputs
│   ├── figures/                  # 12 figures (SVG + PNG)
│   ├── tables/                   # 8 tables (CSV)
│   └── data/                     # Predictions, statistics
├── manuscript/                   # npj Microgravity manuscript
│   ├── manuscript.md
│   ├── manuscript.tex
│   └── manuscript.pdf
├── Dockerfile                    # Reproducible environment
├── requirements.txt              # Python dependencies
├── CITATION.cff                  # Citation metadata
├── LICENSE                       # MIT license
└── README.md
```

## Data availability

The raw and processed transcriptomics data are publicly available from NASA GeneLab:
- Repository: https://genelab.nasa.gov
- Studies: OSD-7, OSD-17, OSD-37, OSD-38, OSD-44, OSD-46, OSD-120, OSD-121,
  OSD-136, OSD-147, OSD-193, OSD-205, OSD-208, OSD-217, OSD-218, OSD-223,
  OSD-251, OSD-281, OSD-314, OSD-321, OSD-346, OSD-427, OSD-437, OSD-480,
  OSD-522, OSD-678

ChronoGauge pre-trained models are available from HuggingFace.

## Reproducibility

```bash
# 1. Build Docker image
docker build -t spaceflight-circadian-decoder .

# 2. Run full pipeline
docker run -v $(pwd)/results:/results spaceflight-circadian-decoder

# 3. Or run step-by-step
pip install -r requirements.txt
python src/data_acquisition.py
python src/metadata_curation.py
python src/run_analysis.py
python src/generate_validation.py
```

## License

- **Code**: MIT License
- **Data**: NASA GeneLab data are in the public domain (NASA Open Data)
- **ChronoGauge models**: See original ChronoGauge license

## Zenodo deposit instructions

1. Create a new upload on Zenodo (https://zenodo.org/deposit/new)
2. Upload this archive as a .zip or .tar.gz
3. Use the metadata from CITATION.cff
4. The DOI will be auto-assigned by Zenodo upon publication
5. Update the DOI in CITATION.cff and manuscript after deposit
