# Spaceflight Circadian Decoder

Deep learning analysis of circadian clock phase disruption in spaceflight-grown *Arabidopsis thaliana* using ChronoGauge and NASA GeneLab transcriptomics data.

## Overview

This repository contains the complete analysis pipeline for applying ChronoGauge — a deep learning circadian time predictor — to all processed *Arabidopsis* spaceflight transcriptomics data from NASA GeneLab. The analysis quantifies circadian phase shifts between spaceflight and ground control samples across 23 studies, 603 samples, and 13 ecotypes.

## Key findings

- **Overall**: Small but significant circadian phase advance under spaceflight (−0.09 h, p = 0.046, I² = 86.5%)
- **Root tissue**: Significant phase advance (−0.17 h, p < 0.001, I² = 8.9%)
- **Dark-grown samples**: Significant phase advance (−0.20 h, p = 0.024)
- **Fork A vs Fork B**: Consistent results regardless of dataset scope

## Repository structure

```
spaceflight-circadian-decoder/
├── src/
│   ├── data_acquisition.py      # Download GeneLab data via OSDR API
│   ├── metadata_curation.py     # Parse ISA-Tab metadata
│   ├── chronogauge_apply.py     # ChronoGauge ensemble inference
│   ├── statistical_analysis.py  # Watson-Williams tests + metafor meta-analysis
│   ├── run_analysis.py          # Main analysis pipeline
│   ├── generate_validation.py   # Validation figures and tables
│   ├── figures/
│   │   └── generate_figures.py  # All main and supplementary figures
│   └── tables/
│       └── generate_tables.py   # All main and supplementary tables
├── config/
│   └── study_lists.json         # Fork A and Fork B study definitions
├── tests/
│   └── test_pipeline.py         # Unit tests
├── manuscript/
│   ├── manuscript.md            # npj Microgravity manuscript
│   ├── manuscript.tex           # LaTeX version
│   └── figures/                 # Figure files for manuscript
├── Dockerfile                   # Reproducible environment
├── requirements.txt             # Python dependencies
├── LICENSE                      # MIT license
└── README.md                    # This file
```

## Requirements

- Python 3.11+
- R 4.4+ with metafor, ggplot2
- TensorFlow 2.x
- ~2 GB disk space for downloaded data

## Quick start

```bash
# Install dependencies
pip install -r requirements.txt

# Download GeneLab data
python src/data_acquisition.py

# Curate metadata
python src/metadata_curation.py

# Run full analysis pipeline
python src/run_analysis.py

# Generate validation figures
python src/generate_validation.py
```

## Docker

```bash
docker build -t spaceflight-circadian-decoder .
docker run -v $(pwd)/results:/results spaceflight-circadian-decoder
```

## Data sources

- **NASA GeneLab**: https://genelab.nasa.gov
- **ChronoGauge models**: HuggingFace (pre-trained RNA-seq, ATH1, and AraGene ensembles)
- **ChronoGauge repository**: https://github.com/[chronogauge-repo]

## Citation

If you use this code, please cite:

```
Barker, R. (2026). Spaceflight alters plant circadian clock phase: A ChronoGauge 
analysis of NASA GeneLab Arabidopsis transcriptomics. npj Microgravity.
```

## License

MIT License — see [LICENSE](LICENSE) for details.
