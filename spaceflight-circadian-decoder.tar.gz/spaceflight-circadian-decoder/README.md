# Spaceflight Circadian Decoder

Deep learning analysis of circadian clock phase disruption in spaceflight-grown *Arabidopsis thaliana* using ChronoGauge and NASA GeneLab transcriptomics data.

## Overview

This repository contains the complete analysis pipeline for applying ChronoGauge — a deep learning circadian time predictor — to all processed *Arabidopsis* spaceflight transcriptomics data from NASA GeneLab. The analysis quantifies circadian phase shifts between spaceflight and ground control samples across 23 studies, 603 samples, and 13 ecotypes.

## Key findings

- **Overall**: Small but significant circadian phase advance under spaceflight (−0.09 h, p = 0.046, I² = 86.5%)
- **Root tissue**: Significant phase advance (−0.17 h, p < 0.001, I² = 8.9%)
- **Dark-grown samples**: Significant phase advance (−0.20 h, p = 0.024)
- **Fork A vs Fork B**: Consistent results regardless of dataset scope
- **Circadian trajectory**: t-SNE centroid distance correlates with phase shift magnitude (Spearman ρ = 0.633, p = 0.005)
- **Gene set enrichment**: OSD-193 shows significant downregulation of the circadian rhythm pathway (GO:0007623, NES = −2.25, FDR = 0.004), with core clock genes (LHY, TOC1, PRR5, CCA1) among the leading edge

## Repository structure

```
spaceflight-circadian-decoder/
├── src/
│   ├── data_acquisition.py      # Download GeneLab data via OSDR API
│   ├── metadata_curation.py     # Parse ISA-Tab metadata
│   ├── chronogauge_apply.py     # ChronoGauge ensemble inference
│   ├── statistical_analysis.py  # Watson-Williams tests + metafor meta-analysis
│   ├── run_analysis.py          # Main analysis pipeline
│   ├── generate_validation.py   # Validation figures and tables
│   ├── trajectory_analysis.py   # t-SNE/PCA circadian trajectory analysis
│   ├── enrichment_analysis.R    # limma-voom DEG + fgsea gene set enrichment
│   ├── generate_dashboard.py    # Generate interactive Plotly dashboard
│   ├── regenerate_figures.py    # Regenerate figures from cached data
│   ├── figures/
│   │   └── generate_figures.py  # All main and supplementary figures
│   └── tables/
│       └── generate_tables.py   # All main and supplementary tables
├── config/
│   └── study_lists.json         # Fork A and Fork B study definitions
├── tests/
│   └── test_pipeline.py         # Unit tests
├── docs/                        # Interactive dashboard (GitHub Pages)
│   ├── index.html               # Main dashboard with 5 interactive views
│   ├── data.js                  # Embedded analysis data
│   ├── plotly.min.js            # Plotly.js (local copy)
│   └── README.md                # Deployment instructions
├── manuscript/
│   ├── manuscript.md            # npj Microgravity manuscript
│   ├── manuscript.tex           # LaTeX version
│   ├── manuscript.pdf           # Compiled PDF
│   ├── figures/                 # Figure files for manuscript
│   └── tables/                  # Supplementary tables
├── Dockerfile                   # Reproducible environment
├── requirements.txt             # Python dependencies
├── LICENSE                      # MIT license
└── README.md                    # This file
```

## Requirements

- Python 3.11+ with TensorFlow, scikit-learn, pandas, matplotlib, plotly
- R 4.4+ with metafor, limma, fgsea, org.At.tair.db, ggplot2
- ~2 GB disk space for downloaded data

## Quick start

```bash
# Install dependencies
pip install -r requirements.txt

# Download GeneLab data
python src/data_acquisition.py

# Curate metadata
python src/metadata_curation.py

# Run full analysis pipeline
python src/run_analysis.py

# Generate validation figures
python src/generate_validation.py

# Regenerate all figures from cached data
python src/regenerate_figures.py

# Circadian trajectory analysis (t-SNE + PCA)
python src/trajectory_analysis.py

# Gene set enrichment analysis (limma-voom + fgsea)
Rscript src/enrichment_analysis.R

# Generate interactive dashboard
python src/generate_dashboard.py
```

## Interactive dashboard

The `docs/` folder contains a self-contained interactive Plotly dashboard deployable to GitHub Pages. It provides five views for exploring the analysis results:

1. **Phase Overview** — Predicted circadian time vs circular variance, with dropdown filters
2. **Forest Plot** — Per-study phase shifts with confidence intervals and pooled estimate
3. **Circadian Fingerprint** — Box plot of circular variance by condition
4. **Clock Genes** — Heatmap of 11 core clock genes across samples
5. **t-SNE Trajectory** — Non-linear embedding of circadian fingerprints

To deploy: push to GitHub, then enable Pages in Settings → Pages → Deploy from branch → main → /docs. See `docs/README.md` for details.

## Docker

```bash
docker build -t spaceflight-circadian-decoder .
docker run -v $(pwd)/results:/results spaceflight-circadian-decoder
```

## Data sources

- **NASA GeneLab**: https://genelab.nasa.gov
- **ChronoGauge models**: HuggingFace (pre-trained RNA-seq, ATH1, and AraGene ensembles)
- **ChronoGauge repository**: https://github.com/[chronogauge-repo]

## Citation

If you use this code, please cite:

```
Barker, R. (2026). Spaceflight alters plant circadian clock phase: A ChronoGauge 
analysis of NASA GeneLab Arabidopsis transcriptomics. npj Microgravity.
```

## License

MIT License — see [LICENSE](LICENSE) for details.
